//
//  APIClient.swift
//  Universal-Link
//
//  Created by Luan Huynh on 6/3/19.
//  Copyright © 2019 Luan Huynh. All rights reserved.
//

import Foundation

class APIClient {
    
    static let shared: APIClient = APIClient()
    
    func request<T: Decodable>(endpoint: Endpoint, completion: @escaping (T) -> Void) {
        let session = URLSession.shared
        let task = session.dataTask(with: endpoint.url) { (data, _, _) in
            do {
                if let data = data {
                    let object = try JSONDecoder().decode(T.self, from: data)
                    DispatchQueue.main.async { completion(object) }
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }

}

enum Endpoint {
    
    case users
    case userDetails(Int)
    
    var url: URL {
        var baseUrl = "https://kl-universal-links-server.herokuapp.com/api"
        
        switch self {
            case .users: baseUrl.append("/users")
            case .userDetails(let id): baseUrl.append("/users/\(id)")
        }
        return URL(string: baseUrl)!
    }
}

