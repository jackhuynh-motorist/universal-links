//
//  Navigator.swift
//  Universal-Link
//
//  Created by Luan Huynh on 6/3/19.
//  Copyright © 2019 Luan Huynh. All rights reserved.
//

import UIKit

struct Navigator {
    
    func getDestination(for url: URL) -> UIViewController? {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let navController = storyboard.instantiateInitialViewController() as? UINavigationController
        let destination = Destination(for: url)
        
        switch destination {
            case .users: return navController
            case .userDetails(let userId):
                guard let userDetailsVC = storyboard.instantiateViewController(withIdentifier: "UserDetailViewController") as? UserDetailViewController else { return nil }
            
                userDetailsVC.userId = userId
                if let nav = navController {
                    nav.pushViewController(userDetailsVC, animated: false)
                }
                
                return navController
            
            case .safari: return nil
        }
    }
    
    enum Destination {
        case users
        case userDetails(Int)
        case safari
        
        init(for url: URL) {
            if url.lastPathComponent == "users" {
                self = .users
            } else if let userId = Int(url.lastPathComponent) {
                self = .userDetails(userId)
            } else {
                self = .safari
            }
        }
    }
}
