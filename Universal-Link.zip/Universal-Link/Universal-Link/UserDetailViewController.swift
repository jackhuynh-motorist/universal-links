//
//  UserDetailViewController.swift
//  Universal-Link
//
//  Created by Luan Huynh on 6/3/19.
//  Copyright © 2019 Luan Huynh. All rights reserved.
//

import UIKit

class UserDetailViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    // MARK: - Properties
    var userId: Int = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()

        requestAPIToGetUserDetail(with: userId)
    }
    
    // MARK: - Functions
    func updateView(with user: User) {
        idLabel.text = "\(user.id)"
        nameLabel.text = "\(user.name)"
        ageLabel.text = "\(user.age)"
    }
    
    // MARK: - Request API
    func requestAPIToGetUserDetail(with userId: Int) {
        APIClient.shared.request(endpoint: .userDetails(userId)) { [weak self] (user: User) in
            guard let this = self else { return }
            this.updateView(with: user)
        }
    }


}
