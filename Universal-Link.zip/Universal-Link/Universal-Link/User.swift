//
//  User.swift
//  Universal-Link
//
//  Created by Luan Huynh on 6/3/19.
//  Copyright © 2019 Luan Huynh. All rights reserved.
//

import Foundation

struct User: Decodable {
    
    let id: Int
    let name: String
    let age: Int
}
