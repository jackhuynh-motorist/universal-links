//
//  UsersListViewController.swift
//  Universal-Link
//
//  Created by Luan Huynh on 6/3/19.
//  Copyright © 2019 Luan Huynh. All rights reserved.
//

import UIKit

class UsersListViewController: UITableViewController {
    
    // MARK: - Properties
    var users: [User] = []
    
    // MARK: - Overrid Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        requestAPIToGetUsers()
    }
    
    // MARK: - TableView
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        let user = users[indexPath.row]
        cell.textLabel?.text = "\(indexPath.row+1). \(user.name)"
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let user = users[indexPath.row]
        performSegue(withIdentifier: "pushToUserDetail", sender: user)
    }
    
    // MARK: - Request API
    func requestAPIToGetUsers() {
        APIClient.shared.request(endpoint: .users) { [weak self] (users: [User]) in
            guard let this = self else { return }
            this.users = users
            this.tableView.reloadData()
        }
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)

        guard let vc = segue.destination as? UserDetailViewController,
            let user = sender as? User
            else { return }

        vc.userId = user.id
    }

}

